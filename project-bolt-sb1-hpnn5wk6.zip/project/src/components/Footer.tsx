import React from 'react';
import { Linkedin, Mail, MapPin, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="py-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Sayan Debnath</h3>
            <p className="text-slate-400 mb-4">
              Electronics & Communication Engineering Student | Robotics & IoT Innovator | 
              AI/Data-Driven Solutions Developer
            </p>
            <div className="flex space-x-4">
              <a href="https://www.linkedin.com/in/sayan-debnath-1106b3245/" target="_blank" rel="noopener noreferrer" className="text-slate-400 hover:text-primary-400 transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="mailto:sayandebnath0921@gmail.com" className="text-slate-400 hover:text-primary-400 transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <a href="#hero" className="text-slate-400 hover:text-white transition-colors">Home</a>
              </li>
              <li>
                <a href="#about" className="text-slate-400 hover:text-white transition-colors">About</a>
              </li>
              <li>
                <a href="#skills" className="text-slate-400 hover:text-white transition-colors">Skills</a>
              </li>
              <li>
                <a href="#experience" className="text-slate-400 hover:text-white transition-colors">Experience</a>
              </li>
              <li>
                <a href="#projects" className="text-slate-400 hover:text-white transition-colors">Projects</a>
              </li>
              <li>
                <a href="#contact" className="text-slate-400 hover:text-white transition-colors">Contact</a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-bold mb-4 text-white">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin size={20} className="text-primary-500 mt-1 mr-2 flex-shrink-0" />
                <span className="text-slate-400">Tripura, India</span>
              </li>
              <li className="flex items-start">
                <Mail size={20} className="text-primary-500 mt-1 mr-2 flex-shrink-0" />
                <a href="mailto:sayandebnath0921@gmail.com" className="text-slate-400 hover:text-white transition-colors">
                  sayandebnath0921@gmail.com
                </a>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col items-center">
          <div className="text-slate-400 text-sm mb-2 flex items-center">
            Designed & Developed with <Heart size={14} className="text-error-500 mx-1" /> in {currentYear}
          </div>
          <p className="text-slate-500 text-xs">
            © {currentYear} Sayan Debnath. All Rights Reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
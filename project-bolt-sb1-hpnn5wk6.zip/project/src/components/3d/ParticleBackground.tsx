import React, { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Points, PointMaterial } from '@react-three/drei';
import * as THREE from 'three';

const ParticleBackground: React.FC = () => {
  const ref = useRef<THREE.Points>(null);
  
  // Generate random particles
  const count = 2000;
  const particles = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);
    const scales = new Float32Array(count);
    const randomness = new Float32Array(count * 3);
    
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Position
      positions[i3] = (Math.random() - 0.5) * 10;
      positions[i3 + 1] = (Math.random() - 0.5) * 10;
      positions[i3 + 2] = (Math.random() - 0.5) * 10;
      
      // Random values for animation
      randomness[i3] = Math.random() * 2 - 1;
      randomness[i3 + 1] = Math.random() * 2 - 1;
      randomness[i3 + 2] = Math.random() * 2 - 1;
      
      // Color (blue to cyan)
      const mixFactor = Math.random();
      colors[i3] = 0.1 + mixFactor * 0.1;  // r
      colors[i3 + 1] = 0.4 + mixFactor * 0.4;  // g
      colors[i3 + 2] = 0.8;  // b
      
      // Size
      scales[i] = Math.random() * 0.5 + 0.5;
    }
    
    return { positions, colors, scales, randomness };
  }, [count]);

  useFrame((state) => {
    if (!ref.current) return;
    
    const { clock } = state;
    const elapsedTime = clock.getElapsedTime();
    
    const positions = ref.current.geometry.attributes.position.array as Float32Array;
    const randomness = particles.randomness;
    
    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      
      // Apply gentle sine wave motion
      const x = particles.positions[i3];
      const y = particles.positions[i3 + 1];
      const z = particles.positions[i3 + 2];
      
      const xOffset = Math.sin(elapsedTime * 0.2 + randomness[i3] * 10) * 0.1;
      const yOffset = Math.cos(elapsedTime * 0.15 + randomness[i3 + 1] * 10) * 0.1;
      const zOffset = Math.sin(elapsedTime * 0.1 + randomness[i3 + 2] * 10) * 0.1;
      
      positions[i3] = x + xOffset;
      positions[i3 + 1] = y + yOffset;
      positions[i3 + 2] = z + zOffset;
    }
    
    ref.current.geometry.attributes.position.needsUpdate = true;
    
    // Rotate the entire particle system
    ref.current.rotation.y = elapsedTime * 0.05;
    ref.current.rotation.z = elapsedTime * 0.03;
  });

  return (
    <group>
      <Points ref={ref} positions={particles.positions} colors={particles.colors} scales={particles.scales}>
        <PointMaterial
          transparent
          vertexColors
          size={0.05}
          sizeAttenuation={true}
          depthWrite={false}
          blending={THREE.AdditiveBlending}
        />
      </Points>
    </group>
  );
};

export default ParticleBackground;
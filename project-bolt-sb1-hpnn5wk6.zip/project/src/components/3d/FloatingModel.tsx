import React, { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface FloatingModelProps {
  position?: [number, number, number];
  rotation?: [number, number, number];
  scale?: number;
}

const FloatingModel: React.FC<FloatingModelProps> = ({
  position = [0, 0, 0],
  rotation = [0, 0, 0],
  scale = 1
}) => {
  const mesh = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!mesh.current) return;
    
    const t = state.clock.getElapsedTime();
    
    // Smooth floating animation
    mesh.current.position.y = position[1] + Math.sin(t * 0.5) * 0.2;
    mesh.current.rotation.y = rotation[1] + t * 0.2;
  });

  return (
    <group ref={mesh} position={position} rotation={rotation} scale={scale}>
      {/* Base platform */}
      <mesh position={[0, -0.5, 0]}>
        <cylinderGeometry args={[2, 2, 0.2, 32]} />
        <meshStandardMaterial color="#1e293b" metalness={0.8} roughness={0.2} />
      </mesh>

      {/* Central hologram effect */}
      <mesh position={[0, 0.5, 0]}>
        <torusGeometry args={[1, 0.1, 16, 100]} />
        <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={2} transparent opacity={0.8} />
      </mesh>

      {/* Floating crystals */}
      {[...Array(5)].map((_, i) => {
        const angle = (i / 5) * Math.PI * 2;
        const radius = 1.2;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        return (
          <mesh key={i} position={[x, 0.8 + Math.sin(i * 1.5) * 0.2, z]}>
            <octahedronGeometry args={[0.2]} />
            <meshStandardMaterial color="#14b8a6" metalness={0.8} roughness={0.2} />
          </mesh>
        );
      })}

      {/* Energy beams */}
      <mesh position={[0, 0, 0]}>
        <cylinderGeometry args={[0.05, 0.05, 2, 8]} />
        <meshStandardMaterial color="#3b82f6" emissive="#3b82f6" emissiveIntensity={2} transparent opacity={0.5} />
      </mesh>

      {/* Orbiting spheres */}
      {[...Array(3)].map((_, i) => {
        const angle = (i / 3) * Math.PI * 2;
        const radius = 0.8;
        const x = Math.cos(angle) * radius;
        const z = Math.sin(angle) * radius;
        return (
          <mesh key={i} position={[x, 0.3, z]}>
            <sphereGeometry args={[0.1, 16, 16]} />
            <meshStandardMaterial color="#f97316" emissive="#f97316" emissiveIntensity={1} />
          </mesh>
        );
      })}
    </group>
  );
};

export default FloatingModel;
import React from 'react';
import { motion } from 'framer-motion';
import { Calendar } from 'lucide-react';

interface TimelineItemProps {
  title: string;
  organization: string;
  period: string;
  description: string | string[];
  isLast?: boolean;
  delay?: number;
}

const TimelineItem: React.FC<TimelineItemProps> = ({
  title,
  organization,
  period,
  description,
  isLast = false,
  delay = 0
}) => {
  const descriptionItems = Array.isArray(description) ? description : [description];
  
  return (
    <motion.div 
      className="relative pl-8"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.4, delay }}
    >
      {/* Timeline dot and line */}
      <div className="absolute left-0 top-0 mt-1.5">
        <div className="w-4 h-4 rounded-full bg-primary-500 relative z-10 ring-4 ring-slate-900" />
        {!isLast && <div className="absolute top-4 left-2 w-0.5 h-full -translate-x-1/2 bg-slate-700" />}
      </div>
      
      <div className="card mb-8">
        <div className="mb-3">
          <div className="flex items-center text-sm text-slate-400 mb-1">
            <Calendar size={14} className="mr-1" />
            <span>{period}</span>
          </div>
          <h3 className="text-xl font-semibold text-white">{title}</h3>
          <p className="text-primary-400">{organization}</p>
        </div>
        
        <div className="space-y-2">
          {descriptionItems.map((item, index) => (
            <p key={index} className="text-slate-300 text-sm">{item}</p>
          ))}
        </div>
      </div>
    </motion.div>
  );
};

export default TimelineItem;
import React from 'react';
import { motion } from 'framer-motion';
import { ExternalLink, Github } from 'lucide-react';

interface ProjectCardProps {
  title: string;
  description: string;
  technologies: string[];
  image?: string;
  githubUrl?: string;
  liveUrl?: string;
  delay?: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({
  title,
  description,
  technologies,
  image,
  githubUrl,
  liveUrl,
  delay = 0
}) => {
  return (
    <motion.div
      className="card group overflow-hidden relative"
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.5, delay }}
      whileHover={{ 
        y: -5,
        transition: { duration: 0.2 }
      }}
    >
      {image && (
        <div className="h-40 mb-4 overflow-hidden rounded-lg">
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
          />
        </div>
      )}
      
      <div className="space-y-3">
        <h3 className="text-xl font-bold text-white">{title}</h3>
        <p className="text-slate-400 text-sm">{description}</p>
        
        <div className="flex flex-wrap gap-2 mt-3">
          {technologies.map((tech, index) => (
            <span 
              key={index}
              className="text-xs px-2 py-1 rounded-full bg-slate-800 text-slate-300"
            >
              {tech}
            </span>
          ))}
        </div>
      </div>
      
      <div className="absolute top-3 right-3 flex space-x-2">
        {githubUrl && (
          <a
            href={githubUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-slate-800 p-2 rounded-full text-white hover:bg-slate-700 transition-colors"
          >
            <Github size={16} />
          </a>
        )}
        
        {liveUrl && (
          <a
            href={liveUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="bg-primary-500 p-2 rounded-full text-white hover:bg-primary-600 transition-colors"
          >
            <ExternalLink size={16} />
          </a>
        )}
      </div>
    </motion.div>
  );
};

export default ProjectCard;
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const Cursor: React.FC = () => {
  const [position, setPosition] = useState({ x: 0, y: 0 });
  const [isPointer, setIsPointer] = useState(false);
  
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setPosition({ x: e.clientX, y: e.clientY });
      
      // Check if cursor is over a clickable element
      const target = e.target as HTMLElement;
      const isClickable = target.tagName === 'BUTTON' || 
                         target.tagName === 'A' || 
                         target.closest('button') || 
                         target.closest('a') ||
                         getComputedStyle(target).cursor === 'pointer';
      
      setIsPointer(isClickable);
    };
    
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);
  
  return (
    <>
      {/* Main cursor */}
      <motion.div
        className={`fixed w-6 h-6 rounded-full z-50 pointer-events-none transform -translate-x-1/2 -translate-y-1/2 border-2 
                    ${isPointer ? 'border-primary-500 scale-125' : 'border-white'}`}
        animate={{ 
          x: position.x, 
          y: position.y,
          transition: { type: 'spring', mass: 0.1, damping: 20 }
        }}
        transition={{ 
          type: 'spring',
          damping: 25,
          stiffness: 400
        }}
      />
      
      {/* Cursor dot */}
      <motion.div
        className="fixed w-2 h-2 bg-white rounded-full z-50 pointer-events-none transform -translate-x-1/2 -translate-y-1/2"
        animate={{ 
          x: position.x, 
          y: position.y,
          backgroundColor: isPointer ? '#3B82F6' : '#FFFFFF'
        }}
        transition={{ 
          type: 'tween',
          ease: 'backOut',
          duration: 0.1
        }}
      />
    </>
  );
};

export default Cursor;
import React from 'react';
import { motion } from 'framer-motion';

interface SkillBadgeProps {
  name: string;
  icon?: React.ReactNode;
  delay?: number;
}

const SkillBadge: React.FC<SkillBadgeProps> = ({ name, icon, delay = 0 }) => {
  return (
    <motion.div
      className="glassmorphism px-4 py-2 rounded-full flex items-center space-x-2 cursor-default transition-all duration-300 hover:scale-105"
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.4, delay }}
    >
      {icon && <span className="text-primary-500">{icon}</span>}
      <span>{name}</span>
    </motion.div>
  );
};

export default SkillBadge;
import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import { Cpu, BarChart2, Users, Code } from 'lucide-react';
import SectionTitle from '../components/ui/SectionTitle';

interface AboutSectionProps {
  ref: React.Ref<HTMLElement>;
}

const AboutSection = forwardRef<HTMLElement, Omit<AboutSectionProps, 'ref'>>((props, ref) => {
  const profilePhoto = "https://jmp.sh/s/JNEnahWDuZTDN6NHFVvN";
  
  return (
    <section ref={ref} id="about" className="section-container">
      <SectionTitle 
        title="About Me" 
        subtitle="Get to know more about my background and expertise."
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <motion.div
          className="relative"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.6 }}
        >
          <div className="relative w-full max-w-md mx-auto">
            {/* Main photo */}
            <div className="aspect-[3/4] rounded-xl overflow-hidden border-4 border-slate-800 shadow-xl">
              <img 
                src={profilePhoto} 
                alt="Sayan Debnath" 
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-6 -right-6 w-full h-full rounded-xl border-4 border-primary-500 -z-10"></div>
            
            <div className="absolute top-4 right-4 glassmorphism px-4 py-2 rounded-full text-sm">
              <span className="flex items-center">
                <span className="w-2 h-2 bg-success-500 rounded-full mr-2"></span>
                Available for opportunities
              </span>
            </div>
          </div>
        </motion.div>
        
        <div>
          <motion.div
            className="mb-6"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            <p className="text-slate-300 mb-4">
              I'm a student of Electronics & Communication Engineering at Tripura Institute of Technology, 
              with a passion for creating intelligent systems that merge hardware, software, and data.
            </p>
            <p className="text-slate-400">
              My technical journey is driven by a deep curiosity for building intelligent systems 
              that solve real-world problems. From designing autonomous robots to developing data-driven 
              applications, I thrive at the intersection of electronics hardware and software innovation.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-8">
            <motion.div
              className="card flex items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: 0.1 }}
            >
              <div className="mr-4 p-3 bg-primary-500/20 rounded-lg">
                <Cpu className="text-primary-500" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white mb-1">Embedded Systems</h3>
                <p className="text-sm text-slate-400">Designing integrated hardware-software solutions</p>
              </div>
            </motion.div>
            
            <motion.div
              className="card flex items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="mr-4 p-3 bg-secondary-500/20 rounded-lg">
                <BarChart2 className="text-secondary-500" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white mb-1">Data Analysis</h3>
                <p className="text-sm text-slate-400">Extracting meaningful insights from complex datasets</p>
              </div>
            </motion.div>
            
            <motion.div
              className="card flex items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: 0.3 }}
            >
              <div className="mr-4 p-3 bg-accent-500/20 rounded-lg">
                <Code className="text-accent-500" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white mb-1">Programming</h3>
                <p className="text-sm text-slate-400">Building robust applications with Python and C</p>
              </div>
            </motion.div>
            
            <motion.div
              className="card flex items-start"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="mr-4 p-3 bg-primary-500/20 rounded-lg">
                <Users className="text-primary-500" size={24} />
              </div>
              <div>
                <h3 className="text-lg font-medium text-white mb-1">Leadership</h3>
                <p className="text-sm text-slate-400">Guiding teams to deliver successful projects</p>
              </div>
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <a href="#contact" className="btn btn-primary">
              Get In Touch
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

export default AboutSection;
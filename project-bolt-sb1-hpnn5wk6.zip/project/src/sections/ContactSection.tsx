import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Linkedin } from 'lucide-react';
import SectionTitle from '../components/ui/SectionTitle';

interface ContactSectionProps {
  ref: React.Ref<HTMLElement>;
}

const ContactSection = forwardRef<HTMLElement, Omit<ContactSectionProps, 'ref'>>((props, ref) => {
  const contactInfo = [
    {
      icon: <Mail className="text-primary-500" size={24} />,
      title: 'Email',
      value: 'sayandebnath0921@gmail.com',
      link: 'mailto:sayandebnath0921@gmail.com'
    },
    {
      icon: <Phone className="text-primary-500" size={24} />,
      title: 'Phone',
      value: '+91 6009937228',
      link: 'tel:+916009937228'
    },
    {
      icon: <MapPin className="text-primary-500" size={24} />,
      title: 'Location',
      value: 'Tripura, India',
      link: null
    },
    {
      icon: <Linkedin className="text-primary-500" size={24} />,
      title: 'LinkedIn',
      value: 'Connect with me',
      link: 'https://www.linkedin.com/in/sayan-debnath-1106b3245/'
    }
  ];
  
  return (
    <section ref={ref} id="contact" className="section-container">
      <SectionTitle 
        title="Contact Me" 
        subtitle="Let's connect and discuss potential opportunities!"
        align="center"
      />
      
      <div className="max-w-3xl mx-auto">
        <motion.h3
          className="text-2xl font-semibold text-white mb-6 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ duration: 0.5 }}
        >
          Get in touch
        </motion.h3>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {contactInfo.map((info, index) => (
            <motion.div
              key={index}
              className="card flex items-center p-6"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-100px' }}
              transition={{ duration: 0.5, delay: 0.1 * (index + 1) }}
            >
              <div className="mr-4 p-3 bg-slate-800 rounded-lg">
                {info.icon}
              </div>
              <div>
                <p className="text-sm text-slate-400">{info.title}</p>
                {info.link ? (
                  <a 
                    href={info.link}
                    target={info.link.startsWith('http') ? '_blank' : undefined}
                    rel={info.link.startsWith('http') ? 'noopener noreferrer' : undefined}
                    className="text-white hover:text-primary-400 transition-colors"
                  >
                    {info.value}
                  </a>
                ) : (
                  <p className="text-white">{info.value}</p>
                )}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
});

export default ContactSection;
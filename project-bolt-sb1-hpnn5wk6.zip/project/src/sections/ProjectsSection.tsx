import React, { forwardRef } from 'react';
import SectionTitle from '../components/ui/SectionTitle';
import ProjectCard from '../components/ui/ProjectCard';

interface ProjectsSectionProps {
  ref: React.Ref<HTMLElement>;
}

const ProjectsSection = forwardRef<HTMLElement, Omit<ProjectsSectionProps, 'ref'>>((props, ref) => {
  const projects = [
    {
      title: 'Fire-Fighting Robot',
      description: 'Autonomous robot using Arduino and flame sensors capable of detecting and extinguishing fire.',
      technologies: ['Arduino', 'C/C++', 'Sensors', 'Robotics'],
      image: 'https://images.pexels.com/photos/2085832/pexels-photo-2085832.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      title: 'Remote Control Robot',
      description: 'Developed a robot controllable via remote with real-time directional movement.',
      technologies: ['Robotics', 'Electronics', 'Wireless Communication'],
      image: 'https://images.pexels.com/photos/8566473/pexels-photo-8566473.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      title: 'Amazon Clone Website',
      description: 'Designed and developed a fully functional e-commerce web app using HTML, CSS, and JavaScript.',
      technologies: ['HTML', 'CSS', 'JavaScript', 'Responsive Design'],
      image: 'https://images.pexels.com/photos/2882634/pexels-photo-2882634.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      title: 'PCB Design',
      description: 'Skilled in designing and simulating printed circuit boards using tools like KiCad and Proteus.',
      technologies: ['KiCad', 'Proteus', 'Circuit Design'],
      image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    },
    {
      title: 'Bulk Email Automation using Python',
      description: 'Developed a Python-based automation tool to send bulk personalized emails efficiently using SMTP and CSV data handling.',
      technologies: ['Python', 'SMTP', 'CSV', 'Automation'],
      image: 'https://images.pexels.com/photos/7887800/pexels-photo-7887800.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
    }
  ];
  
  return (
    <section ref={ref} id="projects" className="section-container">
      <SectionTitle 
        title="Projects" 
        subtitle="A showcase of my work and technical capabilities."
      />
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {projects.map((project, index) => (
          <ProjectCard
            key={index}
            title={project.title}
            description={project.description}
            technologies={project.technologies}
            image={project.image}
            delay={0.1 * index}
          />
        ))}
      </div>
    </section>
  );
});

export default ProjectsSection;
import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import {
  Code, 
  Database, 
  LayoutGrid, 
  Cpu, 
  PenTool, 
  ChevronRight,
  Braces,
  Globe,
  BarChart,
  Bot,
  Terminal,
  Server
} from 'lucide-react';
import SectionTitle from '../components/ui/SectionTitle';
import SkillBadge from '../components/ui/SkillBadge';

interface SkillsSectionProps {
  ref: React.Ref<HTMLElement>;
}

const SkillsSection = forwardRef<HTMLElement, Omit<SkillsSectionProps, 'ref'>>((props, ref) => {
  const programmingSkills = [
    { name: 'Python', icon: <Code size={16} /> },
    { name: 'C', icon: <Terminal size={16} /> },
  ];
  
  const webSkills = [
    { name: 'HTML', icon: <LayoutGrid size={16} /> },
    { name: 'CSS', icon: <PenTool size={16} /> },
    { name: 'JavaScript', icon: <Braces size={16} /> },
  ];
  
  const coreSkills = [
    { name: 'Robotics', icon: <Bot size={16} /> },
    { name: 'Embedded Systems', icon: <Cpu size={16} /> },
    { name: 'IoT', icon: <Server size={16} /> },
    { name: 'AI Problem Solving', icon: <ChevronRight size={16} /> },
  ];
  
  const aiDataSkills = [
    { name: 'Statistics & Probability', icon: <BarChart size={16} /> },
    { name: 'Big Data Technologies', icon: <Database size={16} /> },
    { name: 'Python Libraries', icon: <Code size={16} /> },
    { name: 'Data Cleaning & Preprocessing', icon: <ChevronRight size={16} /> },
    { name: 'Domain-Specific Knowledge', icon: <Globe size={16} /> },
  ];
  
  const softSkills = [
    { name: 'Leadership', icon: <ChevronRight size={16} /> },
    { name: 'Teamwork', icon: <ChevronRight size={16} /> },
    { name: 'Communication', icon: <ChevronRight size={16} /> },
    { name: 'Project Management', icon: <ChevronRight size={16} /> },
  ];
  
  return (
    <section ref={ref} id="skills" className="section-container">
      <SectionTitle 
        title="My Skills" 
        subtitle="A comprehensive overview of my technical expertise and capabilities."
        align="center"
      />
      
      <div className="space-y-12">
        <div>
          <motion.h3
            className="section-subheading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            Programming Languages
          </motion.h3>
          
          <div className="flex flex-wrap gap-3">
            {programmingSkills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                icon={skill.icon} 
                delay={0.1 * index}
              />
            ))}
          </div>
        </div>
        
        <div>
          <motion.h3
            className="section-subheading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            Web Development
          </motion.h3>
          
          <div className="flex flex-wrap gap-3">
            {webSkills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                icon={skill.icon} 
                delay={0.1 * index}
              />
            ))}
          </div>
        </div>
        
        <div>
          <motion.h3
            className="section-subheading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            Core Technical Skills
          </motion.h3>
          
          <div className="flex flex-wrap gap-3">
            {coreSkills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                icon={skill.icon} 
                delay={0.1 * index}
              />
            ))}
          </div>
        </div>
        
        <div>
          <motion.h3
            className="section-subheading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            AI & Data Science
          </motion.h3>
          
          <div className="flex flex-wrap gap-3">
            {aiDataSkills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                icon={skill.icon} 
                delay={0.1 * index}
              />
            ))}
          </div>
        </div>
        
        <div>
          <motion.h3
            className="section-subheading"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-100px' }}
            transition={{ duration: 0.5 }}
          >
            Soft Skills
          </motion.h3>
          
          <div className="flex flex-wrap gap-3">
            {softSkills.map((skill, index) => (
              <SkillBadge 
                key={skill.name} 
                name={skill.name} 
                icon={skill.icon} 
                delay={0.1 * index}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

export default SkillsSection;
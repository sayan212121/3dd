import React, { forwardRef } from 'react';
import { motion } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, PerspectiveCamera, Environment } from '@react-three/drei';
import { Download, ArrowDown } from 'lucide-react';
import FloatingModel from '../components/3d/FloatingModel';

interface HeroSectionProps {
  ref: React.Ref<HTMLElement>;
}

const HeroSection = forwardRef<HTMLElement, Omit<HeroSectionProps, 'ref'>>((props, ref) => {
  return (
    <section ref={ref} id="hero" className="min-h-screen flex flex-col justify-center relative overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div className="flex flex-col justify-center">
            <motion.h1
              className="text-4xl sm:text-5xl md:text-6xl font-bold mb-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <span className="block text-white">Hi, I'm</span>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-400 to-secondary-400">Sayan Debnath</span>
            </motion.h1>
            
            <motion.div
              className="mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <p className="text-xl text-slate-300 mb-4">
                Electronics & Communication Engineering Student | Robotics & IoT Innovator | 
                AI/Data-Driven Solutions Developer
              </p>
              <p className="text-slate-400">
                Based in Tripura, India, I combine hardware expertise with software innovation
                to create intelligent solutions at the intersection of electronics, robotics, and AI.
              </p>
            </motion.div>
            
            <motion.div
              className="flex flex-wrap gap-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <a href="#contact" className="btn btn-primary">
                Contact Me
              </a>
              <a href="#" className="btn btn-outline flex items-center">
                <Download size={16} className="mr-2" />
                Download CV
              </a>
            </motion.div>
          </div>
          
          <div className="h-[400px] lg:h-[500px] w-full relative order-first lg:order-last">
            {/* 3D Model Container */}
            <div className="absolute inset-0 rounded-xl overflow-hidden glassmorphism">
              <Canvas>
                <PerspectiveCamera makeDefault position={[0, 0, 5]} />
                <ambientLight intensity={0.5} />
                <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={1} castShadow />
                <FloatingModel position={[0, 0, 0]} scale={1.5} />
                <Environment preset="city" />
                <OrbitControls 
                  enableZoom={false} 
                  autoRotate 
                  autoRotateSpeed={1} 
                  minPolarAngle={Math.PI / 3} 
                  maxPolarAngle={Math.PI / 1.8} 
                />
              </Canvas>
            </div>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 z-10">
        <motion.a
          href="#about"
          className="flex flex-col items-center justify-center text-slate-400 hover:text-white transition-colors"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ 
            duration: 0.5, 
            delay: 0.6,
            repeat: Infinity,
            repeatType: 'reverse',
            repeatDelay: 0.2
          }}
        >
          <span className="mb-2 text-sm">Scroll Down</span>
          <ArrowDown size={20} />
        </motion.a>
      </div>
    </section>
  );
});

export default HeroSection;
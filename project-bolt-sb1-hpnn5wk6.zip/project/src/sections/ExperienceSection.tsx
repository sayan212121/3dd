import React, { forwardRef } from 'react';
import SectionTitle from '../components/ui/SectionTitle';
import TimelineItem from '../components/ui/TimelineItem';

interface ExperienceSectionProps {
  ref: React.Ref<HTMLElement>;
}

const ExperienceSection = forwardRef<HTMLElement, Omit<ExperienceSectionProps, 'ref'>>((props, ref) => {
  const experiences = [
    {
      title: 'Intern',
      organization: 'Agartala Airport Authority',
      period: '2024',
      description: [
        'Gained hands-on exposure to communication systems and automation technologies.',
        'Worked closely with technical teams to understand the infrastructure behind airport operations.'
      ]
    },
    {
      title: 'Data Analytics and Visualization Job Simulation',
      organization: 'Accenture North America (Forage)',
      period: 'April 2025',
      description: [
        'Completed simulation advising a hypothetical social media client as a Data Analyst.',
        'Cleaned, modelled and analyzed 7 datasets to uncover insights into content trends.',
        'Prepared a PowerPoint deck and video presentation to communicate key insights.'
      ]
    }
  ];
  
  const education = [
    {
      title: 'B.Tech in Electronics and Communication Engineering',
      organization: 'Tripura Institute of Technology – Agartala, Tripura',
      period: '2022 - 2026 (Expected)',
      description: 'Focusing on core electronics principles and modern communication technologies.'
    },
    {
      title: '12th Grade (PCMB)',
      organization: 'Kamini Kumar Singha Memorial H.S. School',
      period: 'Completed in 2022',
      description: 'Completed higher secondary education with focus on Physics, Chemistry, Mathematics, and Biology.'
    }
  ];
  
  const certificates = [
    {
      title: 'Python',
      organization: 'Oneroadmap',
      period: '2023',
      description: 'Comprehensive Python programming certification covering core concepts and advanced topics.'
    },
    {
      title: 'AWS Skill Builder Learner Guide',
      organization: 'AWS',
      period: '2024',
      description: 'Foundational knowledge of AWS cloud services and architectures.'
    },
    {
      title: 'Data Analytics and Visualization Job Simulation',
      organization: 'Accenture',
      period: '2025',
      description: 'Hands-on experience with real-world data analysis and visualization techniques.'
    },
    {
      title: 'Web Developer',
      organization: 'Udemy',
      period: '2023',
      description: 'Modern web development techniques and best practices.'
    },
    {
      title: 'AI and Data Scientist',
      organization: 'Oneroadmap',
      period: '2024',
      description: 'Comprehensive training in AI algorithms and data science methodologies.'
    }
  ];
  
  return (
    <section ref={ref} id="experience" className="section-container">
      <SectionTitle 
        title="Experience & Education" 
        subtitle="My professional journey and academic background."
      />
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
        <div>
          <h3 className="section-subheading">Work Experience</h3>
          <div className="mt-6">
            {experiences.map((exp, index) => (
              <TimelineItem
                key={index}
                title={exp.title}
                organization={exp.organization}
                period={exp.period}
                description={exp.description}
                isLast={index === experiences.length - 1}
                delay={0.2 * index}
              />
            ))}
          </div>
        </div>
        
        <div>
          <h3 className="section-subheading">Education</h3>
          <div className="mt-6">
            {education.map((edu, index) => (
              <TimelineItem
                key={index}
                title={edu.title}
                organization={edu.organization}
                period={edu.period}
                description={edu.description}
                isLast={index === education.length - 1}
                delay={0.2 * index}
              />
            ))}
          </div>
          
          <h3 className="section-subheading mt-10">Certificates</h3>
          <div className="mt-6">
            {certificates.map((cert, index) => (
              <TimelineItem
                key={index}
                title={cert.title}
                organization={cert.organization}
                period={cert.period}
                description={cert.description}
                isLast={index === certificates.length - 1}
                delay={0.2 * index}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

export default ExperienceSection;
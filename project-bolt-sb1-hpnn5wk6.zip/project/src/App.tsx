import React, { useRef, useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Canvas } from '@react-three/fiber';
import Navbar from './components/Navbar';
import ParticleBackground from './components/3d/ParticleBackground';
import HeroSection from './sections/HeroSection';
import AboutSection from './sections/AboutSection';
import SkillsSection from './sections/SkillsSection';
import ExperienceSection from './sections/ExperienceSection';
import ProjectsSection from './sections/ProjectsSection';
import ContactSection from './sections/ContactSection';
import Footer from './components/Footer';
import ScrollProgress from './components/ui/ScrollProgress';
import Cursor from './components/ui/Cursor';

function App() {
  const [activeSection, setActiveSection] = useState('hero');
  const sectionsRef = useRef<{ [key: string]: React.RefObject<HTMLElement> }>({
    hero: useRef(null),
    about: useRef(null),
    skills: useRef(null),
    experience: useRef(null),
    projects: useRef(null),
    contact: useRef(null),
  });

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY + window.innerHeight / 3;
      
      for (const section in sectionsRef.current) {
        const element = sectionsRef.current[section].current;
        if (!element) continue;
        
        const offsetTop = element.offsetTop;
        const offsetHeight = element.offsetHeight;
        
        if (scrollPosition >= offsetTop && scrollPosition < offsetTop + offsetHeight) {
          setActiveSection(section);
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className="relative">
      <Cursor />
      <ScrollProgress />
      
      <div className="fixed top-0 left-0 w-full h-screen -z-10">
        <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
          <ParticleBackground />
        </Canvas>
      </div>
      
      <Navbar activeSection={activeSection} sectionsRef={sectionsRef} />

      <main>
        <HeroSection ref={sectionsRef.current.hero} />
        <AboutSection ref={sectionsRef.current.about} />
        <SkillsSection ref={sectionsRef.current.skills} />
        <ExperienceSection ref={sectionsRef.current.experience} />
        <ProjectsSection ref={sectionsRef.current.projects} />
        <ContactSection ref={sectionsRef.current.contact} />
      </main>
      
      <Footer />
    </div>
  );
}

export default App;